# Flame Language

**Flame** is a domain-specific language (DSL) for fire behavior modeling and operational decision support, created by **Daniel Ricardo Maranhão Santana** under the institution **Anternative 3**.

This repository contains the language specification, whitepaper, interpreter, examples, and documentation.

## 🔥 Features
- Declarative syntax for modeling fire risk and operational actions
- Human-readable structure inspired by natural language
- Interpreter written in Python
- Outputs in PDF, CSV, JSON, and Flame format
- Ideal for civil protection, forestry, and emergency planning

## 📄 Whitepaper
See [`docs/Flame_Whitepaper_Anternative3.pdf`](docs/Flame_Whitepaper_Anternative3.pdf)

## 📜 Example

```flame
regiao Centro {
    dia 2025-07-03 {
        comportamento_fogo {
            intensidade: extrema
            haines: 11
            isi: muito_rapida
            tipologia: topografico > vento > convectivo
            recomendacao: vigilancia_armada
        }
    }
}
```

## 🧠 Developed by
Daniel Ricardo Maranhão Santana  
Anternative 3 · Awareness
